# Neith Othello Gallery

Install dependencies:
```bash
npm install
npm run dev
```